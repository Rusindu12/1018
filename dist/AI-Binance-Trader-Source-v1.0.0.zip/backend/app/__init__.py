"""AI Binance Trader — FastAPI backend package."""
__version__ = "1.0.0"
